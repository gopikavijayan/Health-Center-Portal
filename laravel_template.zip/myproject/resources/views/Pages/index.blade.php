@extends('Layouts.app')
@section('content')

<h1>Home</h1>
<h1>{{$titles}}</h1>
<p>Hello</p>

@endsection