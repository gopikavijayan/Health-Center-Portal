<?php $__env->startSection('content'); ?>
<h1>Mariya</h1>
<b><i><h3>Ajce</h3></i></b>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>