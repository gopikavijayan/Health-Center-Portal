<form method="POST" action="<?php echo e(route('book.store')); ?>">
<?php echo csrf_field(); ?>

title:<input type="text" name="title" /><br/>
body:<input type="text" name="body" />
<button type="submit">ADD</button>
</form>
