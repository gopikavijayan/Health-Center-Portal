<form method="POST" action="{{route('book.store')}}">
@csrf

title:<input type="text" name="title" /><br/>
body:<input type="text" name="body" />
<button type="submit">ADD</button>
</form>
