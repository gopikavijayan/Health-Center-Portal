@extends('layouts.app1')
@section('content')

<h1>Index Page</h1>
<h1>This is the index page</h1>
<h2>
	<h2>{{$name}}
</h2>
@endsection