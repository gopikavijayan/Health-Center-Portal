﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Connectivity.Models
{
    public class CusomerContextcs:DbContext
    {
        public CusomerContextcs()
            : base("Mycon")
        {
            DropCreateDatabaseIfModelChanges<CusomerContextcs> d = new DropCreateDatabaseIfModelChanges<CusomerContextcs>();
            Database.SetInitializer<CusomerContextcs>(d);
        }
        public DbSet<Customer> Customers { get; set; }
    }
}