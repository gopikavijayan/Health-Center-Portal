﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Connectivity.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage="required")]
        [Display(Name="Customer name")]
        public string cname { get; set; }

        [Required(ErrorMessage = "required")]
        [Display(Name = "Customer address")]
        [DataType(DataType.MultilineText)]
        public string caddress { get; set; }

        [Required(ErrorMessage = "reduired")]
        [Display(Name = "Customer email")]
        public string cemail { get; set; }

        [Required(ErrorMessage = "reduired")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string cpass { get; set; }
        
    }
}