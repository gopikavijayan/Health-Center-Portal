export class student 
{   
    id?:number;
    name:string;
    username:string;
    pswrd:string;
    
    constructor()
    {
        this.name='';
        this.username='';
    }
}