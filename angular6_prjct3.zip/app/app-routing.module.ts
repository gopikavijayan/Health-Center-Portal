import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { Header3Component } from './header3/header3.component';

const routes: Routes = [{path:"home",component:ProfileComponent},
{path:"feature",component:Header3Component}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
