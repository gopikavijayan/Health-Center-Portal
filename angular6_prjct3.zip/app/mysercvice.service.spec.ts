import { TestBed } from '@angular/core/testing';

import { MysercviceService } from './mysercvice.service';

describe('MysercviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MysercviceService = TestBed.get(MysercviceService);
    expect(service).toBeTruthy();
  });
});
