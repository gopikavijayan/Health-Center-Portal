import { Component, OnInit } from '@angular/core';
import { checkAndUpdateBinding } from '@angular/core/src/view/util';
import {student} from '../student';
import {NgForm} from '@angular/forms';
import {MysercviceService} from '../mysercvice.service';
import { from } from 'rxjs';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
user:any;
check:boolean=true;
student=new student();
isregistered=false;

  constructor(private applyservice:MysercviceService) { }
    
  // this.user={name:'Gopika Vijayan',
  // job:'Software Developer',
  // address:'1234 street ,city,state,10098',
  // Phone: []}
  // }
  togglecheck(){
    this.check=!this.check;
  }

 
  ngOnInit() {


  }
  register(f: NgForm)
  {
    this.applyservice.store(this.student).subscribe(
      data=>
      {
        this.isregistered=true;
        console.log("registered successfully");
        f.reset();
    },
    err=>
    {
      this.isregistered=false;
    })
  }


}
