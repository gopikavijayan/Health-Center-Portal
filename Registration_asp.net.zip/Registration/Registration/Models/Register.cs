﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Registration.Models
{
    public class Register
    {
        
       
        public string sname { get; set; }


       [Required(ErrorMessage = "Cannot be empty")]
       [Display(Name = "Student address")]
        public string saddress { get; set; }


        public string sgender { get; set; }

        [Required(ErrorMessage = "Cannot be empty")]
        [Display(Name = "Course")]
        public string scourse { get; set; }
        public string simage { get; set; }

        [Required(ErrorMessage = "Cannot be empty")]
        [Display(Name = "Student email")]
        public string semail { get; set; }

        [Required(ErrorMessage = "Cannot be empty")]
        [Display(Name = "Username")]
        public string suser { get; set; }

        [Required(ErrorMessage = "Cannot be empty")]
        [Display(Name = "Password")]
        public string spass { get; set; }

        [Required(ErrorMessage = "Cannot be empty")]
        [Display(Name = "Confirm password")]
        public string scpass { get; set; }
        
    
    }
    public enum Course
    {
        mca,
        mba,
        mcom
    }
}