<form method="post" action="{{route('student.update',$students->id)}}">
@method('PATCH')
@csrf
 Name<input type="text" name="name" value="{{$students->name}}"/>
 Rollno<input type="text" name="rollno" value="{{$students->rollno}}"/>
 Batch<input type="text" name="batch" value="{{$students->batch}}"/>
 <button type="submit">update</button>
 </form>