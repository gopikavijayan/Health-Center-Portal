<form method="POST" action="{{route('student.store')}}">
@csrf

Name:<input type="text" name="name" /><br/>
Rollno:<input type="text" name="rollno" /><br/>
Batch:<input type="text" name="batch" /><br/>
<button type="submit">ADD</button>
</form>
