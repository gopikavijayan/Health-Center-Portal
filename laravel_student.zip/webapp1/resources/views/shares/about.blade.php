@extends('layouts.app1')
@section('content')

<h1>About Page</h1>
<h1>Hi...This is the about page</h1>

@endsection