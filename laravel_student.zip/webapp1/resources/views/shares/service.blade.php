@extends('layouts.app1')
@section('content')

<h1>Service Page</h1>
<h1>This is the service page</h1>

@endsection
