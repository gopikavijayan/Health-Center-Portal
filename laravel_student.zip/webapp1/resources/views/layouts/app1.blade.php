<html>
<head></head>
<body>
	<div>
		<a href="/about">About</a>
		<a href="/index">Index</a>
		<a href="/service">Service</a>
	</div>
	@yield('content');
</body>
</html>
