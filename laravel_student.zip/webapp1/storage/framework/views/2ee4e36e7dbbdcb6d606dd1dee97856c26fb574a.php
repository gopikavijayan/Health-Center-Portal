<form method="post" action="<?php echo e(route('student.update',$students->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
 Name<input type="text" name="name" value="<?php echo e($students->name); ?>"/>
 Rollno<input type="text" name="rollno" value="<?php echo e($students->rollno); ?>"/>
 Batch<input type="text" name="batch" value="<?php echo e($students->batch); ?>"/>
 <button type="submit">update</button>
 </form>