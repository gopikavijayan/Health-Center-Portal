<html>
<head></head>
<body>
	<div>
		<a href="/about">About</a>
		<a href="/index">Index</a>
		<a href="/service">Service</a>
	</div>
	<?php echo $__env->yieldContent('content'); ?>;
</body>
</html>
