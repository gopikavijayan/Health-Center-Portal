<form method="POST" action="<?php echo e(route('student.store')); ?>">
<?php echo csrf_field(); ?>

Name:<input type="text" name="name" /><br/>
Rollno:<input type="text" name="rollno" /><br/>
Batch:<input type="text" name="batch" /><br/>
<button type="submit">ADD</button>
</form>
