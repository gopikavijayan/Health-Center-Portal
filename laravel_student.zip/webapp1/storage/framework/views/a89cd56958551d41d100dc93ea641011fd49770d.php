<form method="POST" action="<?php echo e(route('books.store')); ?>">
<?php echo csrf_field(); ?>

title:<input type="text" name="title" /><br/>
body:<input type="text" name="body" />
<button type="submit">ADD</button>
</form>
